#!/bin/bash

dir_path="/home/yoginderbagga/ready-bash"

if [ -z "$(ls -A "$dir_path")" ]; then
	echo "Directory is empty"
else
	echo "Directory is not empty"
fi
