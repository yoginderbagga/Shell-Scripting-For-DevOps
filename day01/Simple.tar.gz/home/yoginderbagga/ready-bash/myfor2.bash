#!/bin/bash

#simple for loop program display range


for number in {1..5}
do
	echo -e "The number displayed is : $number \n"
done

