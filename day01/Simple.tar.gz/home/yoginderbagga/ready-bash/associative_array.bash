#!/bin/bash

###############################
#	Name: Yoginder Bagga
#	Task: Create associative array
#	Version : v1
#


# Declare associateive array variable
declare -A TEAM_INDIA



# Add players to associate array
TEAM_INDIA[Batsman]="Sachin"
TEAM_INDIA[Bowler]="Harbhajan"
TEAM_INDIA[Fielder]="Ravindra"



# Print the value of particular key
echo "Player selected is : " ${TEAM_INDIA[Bowler]}

