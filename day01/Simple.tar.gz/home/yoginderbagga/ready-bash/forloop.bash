#!/bin/bash

#declaring the for loop

for myvalue in {4..7}
do 
	echo "Go to shop $myvalue times"
done
