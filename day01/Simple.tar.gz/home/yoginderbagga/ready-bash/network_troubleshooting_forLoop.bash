#!/bin/bash

#Troubleshoot network connectivity using : PING, TRACEROUTE, NSLOOKUP

#declare IP address
IP_Addr=("8.8.8.8" "127.0.0.1")

#declare for loop to run tests on each IP

for each_IP in "${IP_Addr[@]}"
do	
	echo -e "-------Checking the host $each_IP--------\n"

	echo -e "RUN PING TEST\n"
	ping -c 3 "$each_IP"
	echo ""

	echo -e  "RUN TRACEROUTE\n"
	traceroute -m 4 "$each_IP"
	echo ""

	echo -e  "RUN NSLOOKUP Test\n"
	nslookup "$each_IP"
	echo ""
done 
