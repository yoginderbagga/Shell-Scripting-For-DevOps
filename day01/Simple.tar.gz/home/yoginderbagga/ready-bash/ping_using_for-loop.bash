#!/bin/bash

#check network connectivity with ping on localhost and Google DNS

#declare IP address of both the host
IP_Addr=("8.8.8.8" "127.0.0.1")
current_user=$(whoami)

#display who is the user logged in
echo -e "You are logged in as : $current_user \n"


#ping both the host

for everyIP in "${IP_Addr[@]}"
do 
	echo -e "CONNECTING TO THE HOSTS: $everyIP \n"
	ping -c 2 "$everyIP"
#echo -e "We are pinging to the host : $everyIP \n"
done 

