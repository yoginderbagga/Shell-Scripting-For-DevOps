#!/bin/bash

#compare two number using if else conditional statement. 

data=65

if [ $data -gt 59  ]; then
	echo "Congratulation, you passed the exam"
else 
	echo "Sorry, you scored less than 60, so you failed"
fi


