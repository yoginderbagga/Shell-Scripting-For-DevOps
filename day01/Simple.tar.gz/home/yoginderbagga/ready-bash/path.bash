#!/bin/bash

#store path in variable

mypath=/usr/bin
path2=~/ready-bash

echo $mypath
echo $path2


#create a directory

mkdir -p /mnt/IBoom
