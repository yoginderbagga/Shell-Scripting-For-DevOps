#!/bin/bash
#Basic If statement 

value=10

if [ $value -gt 8 ]; then
	echo "Number is greater than 10" 
fi

