#!/bin/bash

#simple program for loop

for mycolor in Blue Orange Green Yellow
do 
	echo -e  "the listed colors are : $mycolor \n"
done 
