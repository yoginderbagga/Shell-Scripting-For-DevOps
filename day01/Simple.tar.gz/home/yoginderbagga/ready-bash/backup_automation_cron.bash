#!/bin/bash


#############################
# Name : Yoginder Bagga
# Date : 17-04-2026
# Version : v1
# Script : Automate the backup of /home/yoginderbagga/ready-bash to destination /mnt/backups
#

#declare the source and destination to keep backup files

SOURCE_LOC="/home/yoginderbagga/ready-bash"
BACKUP_DEST="/mnt/backups"
BACKUP_FILE="backup-bash_$(date +'%Y%m%d_%H%M%S').tar.gz"



#create backup directory if not exist
mkdir -p "$BACKUP_DEST"


#command to start the backup along with filename+date
tar -cvzf "${BACKUP_DEST}/${BACKUP_FILE}" "$SOURCE_LOC"


echo "Backup of $SOURCE_LOC completed successfully"


