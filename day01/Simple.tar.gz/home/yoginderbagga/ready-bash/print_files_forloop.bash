#!/bin/bash

FILES="/home/yoginderbagga/ready-bash/*"

for every_file in $FILES
do 
	echo "$every_file"
done
