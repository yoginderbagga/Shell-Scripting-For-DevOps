#!/bin/bash

########################################

#	Name: Yoginder Bagga
#	Script: Backup automation
#	Version: v1 ( revision ) 	
#
#
########################################




# The file you're taking the backup of

SOURCE="/home/yoginderbagga/ready-bash"
DESTINATION="/home/yoginderbagga/Downloads/BackupData"
NEW_FILE="PACKAGED_Backup_$(date +'%Y%m%d_%h%m%s').tar.gz"


mkdir -p "$DESTINATION"

if find "$SOURCE" -type f -mtime +1 | grep -q . 
then 
	echo "Changes detected. Taking the backup..."
	tar -czvf "$DESTINATION/$NEW_FILE" "$SOURCE"
else	
	echo "No changes detected. Skipping backup."
fi










