#!/bin/bash


###################################
# Name : Yoginder Bagga
# Date : 17-04-2026
# Version : v3
# Script : Backup at /mnt/backups + Upload to AWS S3
###################################

#variable

SOURCE_LOC="/home/yoginderbagga/ready-bash"
BACKUP_DEST="/mnt/backups"
DATE=$(date + '%Y%m%d_%H%M%S')
BACKUP_FILE="backup-bash_$(date +'%Y%m%d_%H%M%S').tar.gz"
LOG_FILE="${BACKUP_DEST}/backup_${DATE}.log"
S3_BUCKET="s3://yoginder-backup-2026"


#Ensure backup directory exists if not created.
mkdir -p "$BACKUP_DEST"


#Start the logging
echo "===== Backup started at $(date) ====" >> "$LOG_FILE"


#create the backup
tar -cvzf "${BACKUP_DEST}/${BACKUP_FILE}" "$SOURCE_LOC" >> "$LOG_FILE" 2>&1




#Upload backup to S3
/usr/bin/aws s3 cp "${BACKUP_DEST}/${BACKUP_FILE}" "$S3_BUCKET" --profile my_profile >> "$LOG_FILE" 2>&1

#Upload log to S3
/usr/bin/aws s3 cp "$LOG_FILE" "$S3_BUCKET" --profile my_profile >> "$LOG_FILE" 2>&1


echo "===== Backup completed at $(date) =====" >> "$LOG_FILE"

