#!/bin/bash

#simple for program with condition

a=1
while [ $a -lt 5 ]
do 	
	echo -e "Hi\n"
	((a++))
done
