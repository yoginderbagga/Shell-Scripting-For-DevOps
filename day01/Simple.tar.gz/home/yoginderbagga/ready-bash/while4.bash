#!/bin/bash 


while read -r PING_TEST; 
do 
	echo "Connecting to server $PING_TEST"
	ping -c 2 "$PING_TEST"
done < IP_Address
