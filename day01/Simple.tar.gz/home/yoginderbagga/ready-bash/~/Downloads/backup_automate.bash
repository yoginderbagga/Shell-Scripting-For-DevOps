#!/bin/bash

########################################

#	Name: Yoginder Bagga
#	Script: Backup automation
#	Version: v1 ( revision ) 	
#
#
########################################




# The file you're taking the backup of

SOURCE="/home/yoginderbagga/ready-bash"
DESTINATION="/home/yoginderbagga/Downloads/BackupData"
NEW_FILE="PACKAGED_Backup_$(date +'%Y%m%d_%h%m%s').tar.gz"


mkdir -p "$DESTINATION"

tar -czvf "$DESTINATION/$NEW_FILE" "$SOURCE"










