#!/bin/bash

#declaring global variable

my_host=$(hostname)

#display hostname results using Global variable
echo -e "Your System Hostname is : $my_host \n"


#creating function with a local variable 
function gethost() {
	
	local test_network=$(ping -c 3 8.8.8.8)
	echo -e "We are now connecting with Google DNS: $test_network\n"
	
	}

gethost

echo "We are again connecting with Google DNS: $test_network"
