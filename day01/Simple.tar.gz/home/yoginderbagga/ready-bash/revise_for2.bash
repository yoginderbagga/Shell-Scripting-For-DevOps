#!/bin/bash

# for loop using the list of value or range of values concept ( Not array based ) 
for EMP_NAME in Manish Nikhil Shubham Abhijeet Akansha 
do
	echo "Employee name started : $EMP_NAME"
done 
