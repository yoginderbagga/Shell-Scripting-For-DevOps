#!/bin/bash

#for loop bash program

for data in 1 2 3
do 
	echo "Print this $data times"
done
