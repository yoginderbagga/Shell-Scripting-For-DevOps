#!/bin/bash

for mynum in 1 2 3 4 
do
	echo -e "The number is: $mynum \n"
done
