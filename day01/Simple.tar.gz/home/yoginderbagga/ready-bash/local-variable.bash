#!/bin/bash

# declaring variable
regional_team="GES-APAC"
group_member=15


# created a function and printing variable's value 
function display() {
	echo "Running inside function, you're a member of: $regional_team"
	echo "Running inside function, total members are: $group_member"
}

display
echo "Running outside function, you're a member of: $regional_team"
