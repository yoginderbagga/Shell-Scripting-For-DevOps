#!/bin/bash

file="files_errors"

if [[ -f $file ]]; then
	while IFS=  read -r line; do
	printf '%s\n' "$line"
	done < "$file"
else 	
	echo "Errors: file not found"
fi

