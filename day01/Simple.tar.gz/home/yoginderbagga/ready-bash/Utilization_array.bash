#!/bin/bash

#####################################
#	Name : Yoginder Bagga
#	Task : Select CPU Utilization using array
#	version : v1
#

declare -A HEALTH_TEST

HEALTH_TEST[CPU_HIGH_PROCESS]=$( ps -eo pcpu,pid,user,args --sort=-pcpu | head -5)


echo -e  "Enter your choic\n"
echo "a) To check top CPU Utlizing process"
echo "b) To kill a process"


read select

if [ "$select" = "a" ]; 
then
	echo -e  "${HEALTH_TEST[CPU_HIGH_PROCESS]}"


elif [ "$select" = "b" ];
then
	TOP_PROCESS=$(ps -eo pcpu,pid,user,args --sort=-pcpu | awk 'NR==2')
		
	echo "the TOP Process"
	echo "$TOP_PROCESS"

	PID=$(echo "$TOP_PROCESS" | awk '{print $2}')

	echo "Do you want to kill PID $PID? (y/n)"
	read confirm

	if [ "$confirm" = "y" ]; then
		kill -9 "$PID"
		echo "Process $PID killed."
	else 
		echo "Operation cancelled."
	fi



else 
	echo "Invalid input"
fi

