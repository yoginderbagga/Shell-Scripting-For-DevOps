#!/bin/bash

my_dir="/home/yoginderbagga/*"

for ifile in $my_dir
do
	echo "Files available are: $ifile"
done
