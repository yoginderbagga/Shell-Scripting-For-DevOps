#!/bin/bash

#eligibility check for commerece or science 

maths=52
english=74
science=51

total=$(( maths + english + science ))

echo -e "Total marks are: $total \n"

# using condition to check eligibility

if [[ $total -ge 160 && $maths -ge 50 && $english -ge 50 &&  $science -ge 50 ]]; then
	echo "You're eligible for the commerce"
elif [ $total -ge 170 ]; then
	echo "You're even eligible for science too"
else 
	echo "Sorry you scored less than 160"
fi 

