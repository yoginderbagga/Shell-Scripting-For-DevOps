#!/bin/bash

#use while loop and display names of all the files in ready-bash


DIR="/home/yoginderbagga/ready-bash"

find "$DIR" -type f | while read file
do
	echo -e "First file is : $file \n"
	
done




