#!/bin/bash
#####################################################
#	script  : awk 
#	purpose : Capture field1 and field 3 logs from the access.log of the nginx.
#	author  : DevOps Team
#	usage   : ./deploy.sh
####################################################

logs=/var/log/nginx/access.log
LOGS_CAPTURED=$(awk '{print $1,$3,$4,$5}' /var/log/nginx/access.log)

echo "Below are the results: $LOGS_CAPTURED" 

