#!/bin/bash

####################
#	name: while program
#	date: 29th April, 2026
#	version: v1,
#	script: 2
#

a=1
while [ $a -lt 5 ]
do
	echo -e "keep printing : $a\n"
	((a++))
done

