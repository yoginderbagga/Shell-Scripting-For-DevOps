#!/bin/bash

#Simple for loop script to display employees names.

# declaring an array to store three names
EMP_NAME=("Saurav" "Gaurav" "Dimple")


# using for loop to print and an array variable
for myname in "${EMP_NAME[@]}"
do
	echo "Your name is : $myname"

done


