#!/bin/bash

#Script for global and local variable use cases, use CURL for the example.


fetch_data=$(curl https://www.google.com)
	echo -e "Retrieving the HTML page of Google \n $fetch_data"

#output the DNS info which you're using.

display_results() {
	local resolv_data=$(cat /etc/resolv.conf)
	echo -e "You are using below DNS server \n $resolv_data"
       		

	}

display_results
	echo -e "PRINT DNS INFO AGAIN \n $resolv_data"
















