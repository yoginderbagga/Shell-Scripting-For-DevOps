#!/bin/bash

# declaring variables
current_date=$(date)
files_list=$(ls -l)
disk_usage_directory=$(du -sh)

# displaying results using command substitite 
echo "Today is \n : $current_date" 
echo "These are files : $files_list"
echo "Total disk usage : $disk_usage_directory"

