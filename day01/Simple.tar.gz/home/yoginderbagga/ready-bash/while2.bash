#!/bin/bash

memory=4
while [ $memory -ge 1 ]
do
	echo "keep iterating in minus $memory"
	((memory--))
done
