#!/bin/bash

# ping Google DNS and run traceroute and nslook if ping responds.


#declare variable
IP_Addr="8.8.8.8"
#Results=$(ping -c 3 $IP_Addr) This was incorrect and used it before.

#capture the ping status immediately
#run ping test and troubleshoot


if ping -c 3 "$IP_Addr" > /dev/null 2>&1 
then
	echo -e "Ping is successfull \n"
	echo -e "Running Traceroute Test\n"
	traceroute -m 3 "$IP_Addr"
	echo ""
	echo -e "Running Nslookup Test\n"
	nslookup "$IP_Addr"
else 
	echo "Ping was not successfull"
fi
