#!/bin/bash


# script for simple reading the inputs

echo -e  "Enter your name \n"
read name
echo -e "Hello $name Welcome to IT \n"
