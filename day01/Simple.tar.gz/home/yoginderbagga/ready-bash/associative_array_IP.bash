#!/bin/bash


###################################
#	Name : Yoginder Bagga
#	Task : Use Assocaite array to display IP
#	Version : v1


#Create an associative array

declare -A IP_DETAILS


#Add individual IP address to IP_DETAILS array

IP_DETAILS[PrivateIP]="192.168.49.1"
IP_DETAILS[EthernetIP]="10.0.2.15"
IP_DETAILS[DockerIP]="172.17.0.1"

#Display IP based on user choice

echo "Choose an option:"
echo "a) Private IP"
echo "b) Ethernet IP"
echo -e "c) Docker IP \n"


read select

if [ "$select" = "a" ];
then
	echo "You have selected:" ${IP_DETAILS[PrivateIP]}

elif [ "$select" = "b" ]; 
then	
	echo "You have selected:" ${IP_DETAILS[EthernetIP]}

elif [ "$select" = "c" ];
then
	echo "You have selected:" ${IP_DETAILS[DockerIP]}

else
	echo "Invalid choice"
fi

