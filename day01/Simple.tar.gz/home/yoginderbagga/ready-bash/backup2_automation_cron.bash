#!/bin/bash

#######################################
# Name : Yoginder Bagga
# Date : 18-04-2026
# Task : Backup automation script with crontab and send to your email address. 
# version : v2


# declare variable 

BACKUP_SOURCE="/home/yoginderbagga/ready-bash"
BACKUP_DESTINATION="/mnt/my_backup"
BACKUP_FILE="Recovery_$(date +%F).tar.gz"


mkdir -p "$BACKUP_DESTINATION"

tar -cvzf "${BACKUP_DESTINATION}/${BACKUP_FILE}" "$BACKUP_SOURCE"

echo "Backup of $BACKUP_SOURCE is completed"






