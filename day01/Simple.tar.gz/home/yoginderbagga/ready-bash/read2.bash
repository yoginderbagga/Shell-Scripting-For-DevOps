#!/bin/bash
echo -e "Enter your name\n"
read name
echo "Your name is : $name"
