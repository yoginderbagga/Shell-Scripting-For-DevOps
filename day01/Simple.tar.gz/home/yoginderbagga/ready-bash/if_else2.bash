#!/bin/bash


# compare marks of three subjects and find if you can get commerce

english=74
maths=52
science=50

if [[ $english -gt 60 && $maths -ge 50 && $science -ge 50 ]]; then
	echo "Number is greater in all three you can get commerce"
else 
	echo "Sorry, try in a difference school"
fi




