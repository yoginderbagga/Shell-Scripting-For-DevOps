#!/bin/bash

find /home/yoginderbagga -type f | while read myfile
do 
	echo "file is $myfile"
done
